//Ignatius Brian Widjaja TP058847
//Richard Senjaya TP060175


package vaccinationsystem;


public class VaccinationSystem {


    public static void main(String[] args) {
        LoginForm lf = new LoginForm();
        lf.setVisible(true);
    }
    
}
